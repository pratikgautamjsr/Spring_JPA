package com.app.jpa;

import java.util.Arrays;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.bean.jpa.Course;
import com.bean.jpa.Student;

public class JPAApp {

	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("MySQL");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = entityManager.getTransaction();

		Student student1 = new Student();
		student1.setStudentId(1);
		student1.setfName("Pratik");
		student1.setmName("Gautam");
		student1.setlName("Karn");

		Student student2 = new Student();
		student1.setStudentId(1);
		student1.setfName("Pratik");
		student1.setmName("Gautam");
		student1.setlName("Karn");

		Course course1 = new Course();
		course1.setCourseId(1);
		course1.setCourseName("Java");
		course1.setStudents(Arrays.asList(student1, student2));

		Course course2 = new Course();
		course1.setCourseId(1);
		course1.setCourseName("Spring");
		course1.setStudents(Arrays.asList(student1, student2));

		Course course3 = new Course();
		course1.setCourseId(1);
		course1.setCourseName("Boot");
		course1.setStudents(Arrays.asList(student1, student2));

		Course course4 = new Course();
		course1.setCourseId(1);
		course1.setCourseName("Hibernate");
		course1.setStudents(Arrays.asList(student1, student2));

		student1.setCourses(Arrays.asList(course1, course2, course3, course4));
		student2.setCourses(Arrays.asList(course1, course2, course3, course4));

		transaction.begin();
		entityManager.persist(student1);
		entityManager.persist(student2);
		transaction.commit();

		Student student3 = entityManager.find(Student.class, 1);
		System.out.println(student3);
		Student student4 = entityManager.find(Student.class, 1);
		System.out.println(student4);
	}
}