package org.cap.boot;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class MainClassNew {

	public static void main(String[] args) {

		EntityManagerFactory factory = Persistence.createEntityManagerFactory("capg");
		EntityManager entityManager = factory.createEntityManager();
		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();

		Query query = entityManager.createQuery("SELECT employeeId, salary FROM Employee");
		List<Object[]> employees = (List<Object[]>) query.getResultList();

		for (Object[] employee : employees) {
			for (int i = 0; i < employee.length; i++) {
				System.out.print(employee[i] + " : ");
			}
			System.out.println("");
		}

		System.out.println("-----------------------------------");

		Query query1 = entityManager.createQuery(
				"SELECT employeeId, salary FROM Employee WHERE salary > (SELECT MIN(salary) FROM Employee)");
		List<Object[]> employees1 = (List<Object[]>) query1.getResultList();

		for (Object[] employee : employees1) {
			for (int i = 0; i < employee.length; i++) {
				System.out.print(employee[i] + " : ");
			}
			System.out.println("");
		}

		System.out.println("-----------------------------------");

		Query query2 = entityManager.createQuery(
				"SELECT employeeId, salary FROM Employee WHERE salary < (SELECT MAX(salary) FROM Employee)");
		List<Object[]> employees2 = (List<Object[]>) query2.getResultList();

		for (Object[] employee : employees2) {
			for (int i = 0; i < employee.length; i++) {
				System.out.print(employee[i] + " : ");
			}
			System.out.println("");
		}

		System.out.println("-----------------------------------");

		Query query3 = entityManager.createQuery(
				"SELECT employeeId, salary FROM Employee WHERE salary > (SELECT AVG(salary) FROM Employee)");
		List<Object[]> employees3 = (List<Object[]>) query3.getResultList();

		for (Object[] employee : employees3) {
			for (int i = 0; i < employee.length; i++) {
				System.out.print(employee[i] + " : ");
			}
			System.out.println("");
		}
		transaction.commit();
		entityManager.close();
		factory.close();
	}
}